import JWT from "../../../components/pages/documentation/auth/JWT";

export default JWT;
