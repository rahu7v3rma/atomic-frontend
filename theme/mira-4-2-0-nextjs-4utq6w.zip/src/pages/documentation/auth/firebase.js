import Firebase from "../../../components/pages/documentation/auth/Firebase";

export default Firebase;
