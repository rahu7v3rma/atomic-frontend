import Auth0 from "../../../components/pages/documentation/auth/Auth0";

export default Auth0;
