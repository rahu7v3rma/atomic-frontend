import Cognito from "../../../components/pages/documentation/auth/Cognito";

export default Cognito;
