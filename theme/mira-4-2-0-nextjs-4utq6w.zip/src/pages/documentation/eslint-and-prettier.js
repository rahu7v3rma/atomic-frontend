import ESLintAndPrettier from "../../components/pages/documentation/ESLintAndPrettier";

export default ESLintAndPrettier;
