import EnvironmentVariables from "../../components/pages/documentation/EnvironmentVariables";

export default EnvironmentVariables;
