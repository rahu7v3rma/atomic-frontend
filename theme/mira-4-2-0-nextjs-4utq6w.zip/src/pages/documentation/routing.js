import Routing from "../../components/pages/documentation/Routing";

export default Routing;
