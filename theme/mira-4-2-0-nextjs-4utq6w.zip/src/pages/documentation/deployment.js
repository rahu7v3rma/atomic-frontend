import Deployment from "../../components/pages/documentation/Deployment";

export default Deployment;
