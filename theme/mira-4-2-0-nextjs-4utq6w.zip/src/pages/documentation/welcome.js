import Welcome from "../../components/pages/documentation/Welcome";

export default Welcome;
