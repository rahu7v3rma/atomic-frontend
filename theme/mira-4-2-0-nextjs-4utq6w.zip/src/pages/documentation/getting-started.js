import GettingStarted from "../../components/pages/documentation/GettingStarted";

export default GettingStarted;
