import APICalls from "../../components/pages/documentation/APICalls";

export default APICalls;
