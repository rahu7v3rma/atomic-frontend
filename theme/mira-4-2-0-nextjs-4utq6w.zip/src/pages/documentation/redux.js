import Redux from "../../components/pages/documentation/Redux";

export default Redux;
