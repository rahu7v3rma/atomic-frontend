import Theming from "../../components/pages/documentation/Theming";

export default Theming;
