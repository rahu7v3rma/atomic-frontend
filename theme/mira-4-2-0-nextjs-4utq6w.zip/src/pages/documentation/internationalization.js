import Internationalization from "../../components/pages/documentation/Internationalization";

export default Internationalization;
