import Support from "../../components/pages/documentation/Support";

export default Support;
