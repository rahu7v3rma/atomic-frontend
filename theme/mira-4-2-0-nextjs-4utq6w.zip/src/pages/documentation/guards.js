import Guards from "../../components/pages/documentation/Guards";

export default Guards;
